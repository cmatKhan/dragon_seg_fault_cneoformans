#!/bin/bash -euo pipefail
dragen-os \
    -r dragmap \
    --RGSM DA3_DA3 --RGID "@RG\tID:HLVWFAFXX.DA3.1\tPU:1\tSM:DA3_DA3\tLB:DA3\tDS:s3://brentlab-ref/KN99/FungiDB-68_CneoformansKN99_Genome.fasta\tPL:ILLUMINA" \
    --num-threads 8 \
    -1 0011.DA3-1_1.fastp.fastq.gz -2 0011.DA3-1_2.fastp.fastq.gz \
    2> >(tee DA3.0011.dragmap.log >&2) > DA3.0011.sam
